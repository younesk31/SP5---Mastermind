//package visualController;
//
//import logicController.Models.Pin;
//import logicController.Models.Round;
//import logicController.RoundHandler;
//import processing.core.PApplet;
//import visualController.processing.GameObject;
//
//public class MasterCode implements GameObject {
//
//    private final MasterMindCode mmc;
//
//    public MasterMindCode(MasterMindCode mmc) {
//        this.mmc = mmc;
//    }
//
//    @Override
//    public void draw(PApplet p){
//        int x;
//        int y = p.height-30;
//        for(Pin p : mmc.get){
//        }
//        }
//    }
//
//    public void newGame(){
//
//    }
//
//    public void colorChanger(int pinPos, int color) {
//
//    }
//
//    @Override
//    public String getName() {
//        return null;
//    }
//
//    @Override
//    public void update(int curtimeMillis, PApplet p) {
//    }
//}
