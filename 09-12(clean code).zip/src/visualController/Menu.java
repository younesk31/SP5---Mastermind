package visualController;

import logicController.Rules;

public class Menu {

    public void showStartMenu() {
    }

    public void showRules() {
        new Rules();
    }

    public void newGame() {


    }

}