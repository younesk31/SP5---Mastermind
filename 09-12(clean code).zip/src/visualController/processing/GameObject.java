package visualController.processing;

public interface GameObject extends Drawable, Updateable {
    String getName();
}
