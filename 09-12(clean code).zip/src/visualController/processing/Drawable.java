package visualController.processing;

import processing.core.PApplet;

public interface Drawable {
    void draw(PApplet p);
}
