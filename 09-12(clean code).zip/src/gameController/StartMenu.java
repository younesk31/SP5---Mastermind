package gameController;

public class StartMenu {

    public void playerVsGame() {

    }

    public void GameVsGame() {

    }

    public void PlayerVsPlayer() {

    }

    public void winLose() {

    }
}
