package gameController;

public class MouseController {

    public void mouseTracker(){

    }

    public void colorInput(){

    }

    public void colorOutput(){

    }
}
